const emoji = require('./config/emoji');
require('dotenv').config();

module.exports = {
    // BOT VERSION //
    botVersion: "3.1.0",
    // MUSIC CONFIG //
    searchPlatform: "spotify", // spotify, soundcloud, deezer, applemusic, youtube (patched from lavalink), youtube music (patched from lavalink)
    // BOT INFO //
    activity: "/help | @sxsvnyd",
    status: "idle", // idle, listening, watching, competing
    activityType: "Listening", // Listening, Watching, Competing, Playing, Custom
    eventListeners: 200, // amount of event listeners
    developers: ['885731228874051624', '932817217614118943'], // developer ids
    noPerms: `You **do not** have the required permissions to use this command!`,
    ownerOnlyCommand: `This command is **only** available for the owner of the bot!`,
    botInvite: "https://discord.com/oauth2/authorize?client_id=1312287803706703902&permissions=8&integration_type=0&scope=bot+applications.commands", // bot invite link
    botServerInvite: "https://discord.gg/titikkumpul", // bot server invite
    banner: "https://cdn.discordapp.com/attachments/1196011705831006210/1312244296849821758/static_1.webp?ex=674bca3c&is=674a78bc&hm=6519c1c97e82a6d9c0732cb0823a40ef428859e77b848300b86d2769ed246bae&", // banner url

    // EMBED COLORS //
    embedColor: "00ff33",
    embedYes: "Green",
    embedNo: "Red",
    
    // TOPGG //
    topggAuth: "anything", // anything as a password
    topggVoteLog: "1260482297355046913", // channel id
    topggPort: "20054", // your server port

    // CHANNEL IDS //
    slashCommandLoggingChannel: "1312294331763396618", // channel id for slash command logging
    suggestionChannel: "1312294331763396618", // channel id for suggestions 
    bugReportChannel: "1312294331763396618", // channel id for bug reports
    botLeaveChannel: "1312294331763396618", // channel id for bot leave
    botJoinChannel: "1312294331763396618", // channel id for bot join
    botUpdateChannel: "1312294331763396618", // channel id for bot updates

    ...emoji
};
