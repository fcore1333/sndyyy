module.exports = [
    {
        host: 'cat.mjba.live',
        identifier: 'Cat 1',
        password: 'Nyaa',
        port: 4000,
        retryAmount: 5,
        retryDelay: 3000,
        secure: false
    },

    module.exports = [
    {
        host: 'cat.mjba.live',
        identifier: 'Cat 1', 
        password: 'Nyaa',
        port: 4000,
        retryAmount: 5,
        retryDelay: 3000,
        secure: false
    },
],
];